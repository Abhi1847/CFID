import React from "react";

function ServiceSubmenu() {
  return <div></div>;
}

export default ServiceSubmenu;
