import React from "react";

function CompaniesSubmenu() {
  return (
    <div className="submenu-container">
      <div className="submenu-item">All companies</div>
      <div className="submenu-item">Advance search</div>
    </div>
  );
}

export default CompaniesSubmenu;
