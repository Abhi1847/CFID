function CompaniesSellSubmenu() {
  return (
    <div className="submenu-container">
      <div className="submenu-item">Animal bedding</div>
      <div className="submenu-item">Architectural millwork</div>
      <div className="submenu-item">Bark</div>
      <div className="submenu-item">Barrels</div>
      <div className="submenu-item">Baskets</div>

      <div className="submenu-item">Beams, laminated</div>
      <div className="submenu-item">Beams, sawn</div>
      <div className="submenu-item">Bed Frames</div>
      <div className="submenu-item">Benches</div>
      <div className="submenu-item">Berries</div>
      <div className="submenu-item">Beams, laminated</div>
      <div className="submenu-item">Beams, sawn</div>
      <div className="submenu-item">Bed Frames</div>
      <div className="submenu-item">Benches</div>
      <div className="submenu-item">Berries</div>
      <div className="submenu-item">Beams, laminated</div>
      <div className="submenu-item">Beams, sawn</div>
      <div className="submenu-item">Bed Frames</div>
      <div className="submenu-item">Benches</div>
      <div className="submenu-item">Berries</div>
      <div className="submenu-item">Beams, laminated</div>
      <div className="submenu-item">Beams, sawn</div>
      <div className="submenu-item">Bed Frames</div>
      <div className="submenu-item">Benches</div>
      <div className="submenu-item">Berries</div>
    </div>
  );
}

export default CompaniesSellSubmenu;
